create procedure clear_jkhis_updatecount
is
 begin
   delete from jkhis_updatecount a
    where (a.updatecount,a.jkname,a.createdate) in
      (select updatecount,jkname,createdate
      from jkhis_updatecount
      group by updatecount,jkname,createdate
      having count(*)>0
      )
      and rowid not in
      (select min(rowid)
      from jkhis_updatecount
      group by updatecount,jkname,createdate
      having count(*)>0
      );
  exception
    when others then
      rollback;
 end ;
/

