create PROCEDURE UPZRBM(I_LSH INTEGER,I_JEH IN VARCHAR2, -- 当前JE
                                   -- I_BMBH  IN VARCHAR2,  -- 当前部门
                                    CODES   OUT VARCHAR2 , ZRBMFHZ OUT VARCHAR2) IS


OLD_ZRBM                 VARCHAR2(500):='';--改变前责任部门            
V_NUM                  INTEGER := 0;--该JEH填写的零件个数
V_NUM1                INTEGER := 0;
V_NUM2                INTEGER := 0;
V_NUM3                INTEGER := 0;
V_BMZD                 VARCHAR2(500):='';--部门字段
S_DSQL                   VARCHAR2(1000):='';--动态sql
V_BMBH                  VARCHAR2(10):=''; --部门编号
V_QZZD                   VARCHAR2(500):='';--前置字段
V_ZRBM                  VARCHAR2(500):='';--责任部门
V_QZZDSFWC         BOOLEAN :=false;--判断前置条件是否都满足
-- 设游标

-- 查找所有填写部门
  CURSOR BM_DATA IS
    SELECT  BMBH  FROM XT_BM ORDER BY BMBH;
  BM_DATA_RECORD BM_DATA%rowtype;

 -- 查找部门对应字段
  CURSOR BMZD_DATA(I_BMBH IN VARCHAR2) IS
    SELECT  BMZD
      FROM XM_JEGK_BMZDB
     WHERE  BMBH = I_BMBH;
  BMZD_DATA_RECORD BMZD_DATA%rowtype;

  -- 查找部门 字段的前置字段
  CURSOR BMQZZD_DATA(I_BMZD IN VARCHAR2) IS
       SELECT QZZD FROM XM_JEGK_BMZDQZTJB A
        WHERE BMZD =I_BMZD ;
  BMQZZD_DATA_RECORD BMQZZD_DATA%rowtype;

BEGIN

     --填写责任部门
     -- 循环所有部门 查看本部门的前置字段是否有填写记录
     -- 如果前置字段有一条填写记录，本部门字段 有一条未填写记录 本部门则为责任部门

      OPEN BM_DATA;
      LOOP
        FETCH BM_DATA
          INTO BM_DATA_RECORD;
        EXIT WHEN BM_DATA%notfound;
        V_BMBH   := BM_DATA_RECORD.BMBH;
        S_DSQL:='';

                    -- 通过部门字段查询前置字段是否完成填写
                    -- 部门字段
                    OPEN BMZD_DATA(V_BMBH);
                         LOOP
                           FETCH BMZD_DATA
                           INTO  BMZD_DATA_RECORD;
                           EXIT WHEN BMZD_DATA%NOTFOUND;
                              V_BMZD := BMZD_DATA_RECORD.BMZD;
                               V_QZZDSFWC :=FALSE;

                              -- 前置字段
                              OPEN BMQZZD_DATA(V_BMZD);
                                 LOOP
                                   FETCH BMQZZD_DATA
                                   INTO BMQZZD_DATA_RECORD;
                                    EXIT WHEN BMQZZD_DATA%NOTFOUND;
                                    V_QZZD := BMQZZD_DATA_RECORD.QZZD;
                                    -- 查询前置字段是否非空
                                    -- 如果为空则本部门 不为 责任部门
                                    -- 如果不为空，则继续查询其他前置字段 是否 为空 如果 都有数据记录
                                    -- 再判断 本部门的字段是否 为空 ，或部分填写 如果为空或部分填写 则本部门为责任部门
                                      IF(V_QZZD IS NULL OR V_QZZD = '')THEN
                                              V_QZZDSFWC := TRUE;
                                      ELSE
                                            -- 特殊处理部分
                                            IF(V_BMBH='0004' AND (V_BMZD ='ZZBGYHYJZBSJ'  OR  V_BMZD='ZZBGYKYJWCSJ' ))THEN
                                               S_DSQL:='SELECT COUNT(1) FROM XM_JEGKMX  WHERE   LSH = '||I_LSH ||' AND JEH = '''||I_JEH||'''   AND ZZ = '||'''CG'''||'  AND CGBXKM IS NOT NULL';
                                               EXECUTE IMMEDIATE(S_DSQL) INTO  V_NUM;
                                                S_DSQL:='SELECT COUNT(1) FROM XM_JEGKMX  WHERE   LSH = '||I_LSH ||' AND JEH = '''||I_JEH||'''   AND ZZ = '||'''CG'''||' AND CGBJJSFCXGH IS NOT NULL ';
                                                EXECUTE IMMEDIATE(S_DSQL) INTO  V_NUM1;
                                                S_DSQL:='SELECT COUNT(1) FROM XM_JEGKMX  WHERE   LSH = '||I_LSH ||' AND JEH = '''||I_JEH||'''   AND ZZ = '||'''CG'''||' AND CGBGZYJYJTGSJ IS NOT NULL ';
                                                EXECUTE IMMEDIATE(S_DSQL) INTO  V_NUM2;

                                                IF(V_NUM>0 AND V_NUM1 >0 AND V_NUM2>0)THEN
                                                    V_QZZDSFWC := TRUE;
                                                    EXIT;
                                                ELSE
                                                    S_DSQL:='SELECT COUNT(1) FROM XM_JEGKMX  WHERE   LSH = '||I_LSH ||' AND JEH = '''||I_JEH||'''   AND ZZ <> '||'''CG'''||'  AND ZZBXKM IS NOT NULL ';
                                                    EXECUTE IMMEDIATE(S_DSQL) INTO  V_NUM;
                                                    S_DSQL:='SELECT COUNT(1) FROM XM_JEGKMX  WHERE   LSH = '||I_LSH ||' AND JEH = '''||I_JEH||'''   AND ZZ <> '||'''CG'''||'  AND ZZBJJSFCXGH IS NOT NULL ';
                                                    EXECUTE IMMEDIATE(S_DSQL) INTO  V_NUM1;
                                                    S_DSQL:='SELECT COUNT(1) FROM XM_JEGKMX  WHERE   LSH = '||I_LSH ||' AND JEH = '''||I_JEH||'''   AND ZZ <> '||'''CG'''||' AND ZZBGZYJYJTGSJ IS NOT NULL ';
                                                    EXECUTE IMMEDIATE(S_DSQL) INTO  V_NUM2;

                                                    IF(V_NUM>0 AND V_NUM1 >0 AND V_NUM2>0)THEN
                                                      V_QZZDSFWC := TRUE;
                                                      EXIT;
                                                    ELSE
                                                      V_QZZDSFWC := FALSE;
                                                      EXIT;
                                                   END IF;
                                                END IF;
                                             ELSIF(V_BMBH='0005' AND  V_BMZD='ZLBSZWT' )THEN
                                                   S_DSQL:='SELECT SUM(count1)  FROM (
                                                   SELECT COUNT(1) count1 FROM XM_JEGKMX  WHERE   LSH = '||I_LSH ||' AND JEH = '''||I_JEH||'''   AND ZZ = '||'''CG'''||'  AND ((CGBGZYJSJTGSJ IS NOT NULL and sffscgb = 0) OR sffscgb = 1) and (ZLBSZJSFHG is null  or ZLBSZWT is null) AND ZZ IS NOT NULL AND CYLJH IS NOT NULL
                                                   UNION ALL
                                                    SELECT COUNT(1) count1 FROM XM_JEGKMX  WHERE   LSH = '||I_LSH ||' AND JEH = '''||I_JEH||'''   AND ZZ <> '||'''CG'''||'  AND ((ZZBGZYJSJTGSJ  IS NOT NULL and sffscgb = 0) OR sffscgb = 1) and (ZLBSZJSFHG is null  or ZLBSZWT is null) AND ZZ IS NOT NULL AND CYLJH IS NOT NULL
                                                   )';
                                                   EXECUTE IMMEDIATE(S_DSQL) INTO  V_NUM;
                                                   IF(V_NUM>=1)THEN
                                                      V_QZZDSFWC := TRUE;
                                                      EXIT;
                                                   ELSE
                                                      V_QZZDSFWC := FALSE;
                                                      EXIT;
                                                   END IF;
                                              ELSIF(V_BMBH='0005' AND V_BMZD='ZLBSZCS')THEN 
                                                 S_DSQL :='SELECT  COUNT(1)  FROM XM_JEGKMX  WHERE  LSH = '||I_LSH ||' AND  JEH = '''||I_JEH||''' ' ||'AND '|| V_BMZD ||' IS  NULL   AND ZZ IS NOT NULL AND CYLJH IS NOT NULL ' ;
                                                 EXECUTE IMMEDIATE(S_DSQL) INTO  V_NUM;
                                                 IF(V_NUM>=1)THEN
                                                    V_QZZDSFWC := TRUE;
                                                    EXIT;
                                                 ELSE
                                                    V_QZZDSFWC := FALSE;
                                                    EXIT;
                                                 END IF;
                                            ELSIF(V_BMBH='0005' AND V_BMZD='ZLBPSWTJSJ')THEN 
                                              S_DSQL :='SELECT  COUNT(1)  FROM XM_JEGKMX  WHERE  LSH = '||I_LSH ||' AND  JEH = '''||I_JEH||''' ' ||'AND '|| V_BMZD ||' IS  NULL  and   SCZBSSZJL is not null and SCZBSSZJHSJ is not null and SCZBSSZJLCJSJ is not null ' ;
                                              EXECUTE IMMEDIATE(S_DSQL) INTO  V_NUM;
                                              IF(V_NUM>=1)THEN
                                                V_QZZDSFWC := TRUE;
                                                EXIT;
                                               ELSE
                                                  V_QZZDSFWC := FALSE;
                                                  EXIT;
                                               END IF;
                                           ELSIF(V_BMBH='0003')THEN 
                                             S_DSQL :='SELECT  COUNT(1)  FROM XM_JEGKMX  WHERE  LSH = '||I_LSH ||' AND  JEH = '''||I_JEH||''' ' ||'AND '|| V_BMZD ||' IS  NULL  and   sffscgb =0  AND ZZ IS NOT NULL AND CYLJH IS NOT NULL ' ;
                                             EXECUTE IMMEDIATE(S_DSQL) INTO  V_NUM;
                                             IF(V_NUM>=1)THEN
                                              V_QZZDSFWC := TRUE;
                                              EXIT;
                                             ELSE
                                                V_QZZDSFWC := FALSE;
                                                EXIT;
                                             END IF;
                                           ELSIF(V_BMBH='0021' AND   V_BMZD ='ZLBSZJSFHG' )THEN
                                                 S_DSQL:='SELECT SUM(count1)  FROM (
                                                 SELECT COUNT(1) count1 FROM XM_JEGKMX  WHERE   LSH = '||I_LSH ||' AND JEH = '''||I_JEH||'''   AND ZZ = '||'''CG'''||'  AND ((CGBGZYJSJTGSJ IS NOT NULL and sffscgb = 0) OR sffscgb = 1) and (ZLBSZJSFHG is null  or ZLBSZWT is null) AND ZZ IS NOT NULL AND CYLJH IS NOT NULL
                                                 UNION ALL
                                                  SELECT COUNT(1) count1 FROM XM_JEGKMX  WHERE   LSH = '||I_LSH ||' AND JEH = '''||I_JEH||'''   AND ZZ <> '||'''CG'''||'  AND ((ZZBGZYJSJTGSJ  IS NOT NULL and sffscgb = 0) OR sffscgb = 1) and (ZLBSZJSFHG is null  or ZLBSZWT is null) AND ZZ IS NOT NULL AND CYLJH IS NOT NULL
                                                 )';
                                                 EXECUTE IMMEDIATE(S_DSQL) INTO  V_NUM;
                                                 IF(V_NUM>=1)THEN
                                                  V_QZZDSFWC := TRUE;
                                                  EXIT;
                                                 ELSE
                                                    V_QZZDSFWC := FALSE;
                                                    EXIT;
                                                 END IF; 
                                            ELSE
                                                S_DSQL :='SELECT  COUNT(1)  FROM XM_JEGKMX  WHERE  LSH = '||I_LSH ||' AND JEH = '''||I_JEH||''' ' ||'AND '|| V_QZZD ||' IS NOT NULL  AND ZZ IS NOT NULL AND CYLJH IS NOT NULL ' ;
                                                 EXECUTE IMMEDIATE(S_DSQL) INTO  V_NUM;
                                                 IF(V_NUM > 0)THEN
                                                      V_QZZDSFWC := TRUE;
                                                 ELSE
                                                      V_QZZDSFWC := FALSE;
                                                      EXIT;
                                                 END IF;
                                             END IF;
                                           
                                            
                                      END IF;
                                 END LOOP;
                               CLOSE BMQZZD_DATA;
                               V_NUM:=0;
                               -- 如果前置条件都满足则
                              IF(V_QZZDSFWC)THEN
                               --如果部门是商品开发部
                                  IF(V_BMBH='0009')THEN
                                       IF(V_BMZD='CPRKYJWCSJ')THEN 
                                            S_DSQL :='SELECT  COUNT(1)  FROM XM_JEGKMX  WHERE  LSH = '||I_LSH ||' AND SFJXCPRK='||'''是'''||' AND  JEH = '''||I_JEH||''' ' ||'AND '|| V_BMZD ||' IS  NULL  AND ZZ IS NOT NULL AND CYLJH IS NOT NULL ' ;
                                       ELSE 
                                          S_DSQL :='SELECT  COUNT(1)  FROM XM_JEGKMX  WHERE  LSH = '||I_LSH ||' AND  JEH = '''||I_JEH||''' ' ||'AND '|| V_BMZD ||' IS  NULL AND ZZ IS NOT NULL AND CYLJH IS NOT NULL  ' ;
                                       END IF;
                                  -- 如果是部门是采购部 看记录中制造字段是否有采购的 如果有则判断是否填写完毕
                                   ELSIF(V_BMBH='0003')THEN
                                        S_DSQL :='SELECT  COUNT(1)  FROM XM_JEGKMX  WHERE  LSH = '||I_LSH ||' AND ZZ='||'''CG'''||' AND JEH = '''||I_JEH||''' ' ||'AND '|| V_BMZD ||' IS  NULL AND ZZ IS NOT NULL AND CYLJH IS NOT NULL ' ;
                                   --如果是质量保证部       
                                   ELSIF(V_BMBH='0005')THEN
                                           IF(V_BMZD='ZLBSZCS')THEN 
                                            S_DSQL :='SELECT  COUNT(1)  FROM XM_JEGKMX  WHERE  LSH = '||I_LSH ||' AND  JEH = '''||I_JEH||''' ' ||'AND '|| V_BMZD ||' IS  NULL  AND ZZ IS NOT NULL AND CYLJH IS NOT NULL ' ;
                                           ELSIF(V_BMZD='ZLBPSWTJSJ')THEN 
                                            S_DSQL :='SELECT  COUNT(1)  FROM XM_JEGKMX  WHERE  LSH = '||I_LSH ||' AND  JEH = '''||I_JEH||''' ' ||'AND '|| V_BMZD ||' IS  NULL  and   SCZBSSZJL is not null and SCZBSSZJHSJ is not null and SCZBSSZJLCJSJ is not null AND ZZ IS NOT NULL AND CYLJH IS NOT NULL ' ;
                                           ELSE S_DSQL :='SELECT  COUNT(1)  FROM XM_JEGKMX  WHERE  LSH = '||I_LSH ||' AND  JEH = '''||I_JEH||''' ' ||'AND '|| V_BMZD ||' IS  NULL AND ZZ IS NOT NULL AND CYLJH IS NOT NULL ' ;
                                       END IF;
                                   --如果部门是制造工程部
                                   ELSIF(V_BMBH='0004')THEN
                                        S_DSQL :='SELECT  COUNT(1)  FROM XM_JEGKMX  WHERE   LSH = '||I_LSH ||' AND ZZ<>'||'''CG'''||' AND JEH = '''||I_JEH||''' ' ||'AND '|| V_BMZD ||' IS  NULL  AND ZZ IS NOT NULL AND CYLJH IS NOT NULL ' ;
                                   ELSE
                                         S_DSQL :='SELECT  COUNT(1)  FROM XM_JEGKMX  WHERE  LSH = '||I_LSH ||' AND  JEH = '''||I_JEH||''' ' ||'AND '|| V_BMZD ||' IS  NULL AND ZZ IS NOT NULL AND CYLJH IS NOT NULL ' ;
                                   END IF;
                                    -- 判断 本字段是否为空 如果为空 则责任部门为本部门
                                    EXECUTE IMMEDIATE(S_DSQL) INTO  V_NUM;
                                END IF;
                                  IF(V_NUM > 0)THEN
                                      V_ZRBM := V_ZRBM||V_BMBH||',';
                                      V_NUM:=0;
                                      EXIT;
                                  END IF;


                          END LOOP;
                    CLOSE BMZD_DATA;

       END LOOP;
    CLOSE BM_DATA;
    
    SELECT ZRBM INTO OLD_ZRBM FROM XM_JEGK WHERE LSH =I_LSH AND  JEH = I_JEH;
    
    IF(OLD_ZRBM != V_ZRBM) THEN ZRBMFHZ := OLD_ZRBM || ';' || V_ZRBM ;
    END IF;
    

   UPDATE XM_JEGK SET ZRBM = V_ZRBM WHERE LSH =I_LSH AND  JEH = I_JEH;
   --SELECT COUNT(1)  INTO V_NUM3 FROM XM_JEGK WHERE    LSH = '||I_LSH ||' AND JEH = '''||I_JEH||'''  AND sfjsbom = 1;
    S_DSQL:='SELECT COUNT(1) FROM XM_JEGK  WHERE   LSH = '||I_LSH ||' AND JEH = '''||I_JEH||'''  AND sfjsbom = 1';
     EXECUTE IMMEDIATE(S_DSQL) INTO  V_NUM3;
   
   IF(V_NUM3 >0 )THEN
     IF(V_ZRBM IS NULL OR V_ZRBM = '' )THEN
        UPDATE XM_JEGK SET JESFTXWC = 1  WHERE LSH =I_LSH AND  JEH = I_JEH;
     ELSE
       UPDATE XM_JEGK SET JESFTXWC = 0  WHERE LSH =I_LSH AND  JEH = I_JEH;
     END IF;
   END IF;

   --CODES := V_ZRBM;
   CODES :=   'SUCCESS';
EXCEPTION
  WHEN OTHERS THEN
   -- CODES := 'ERROR';
   CODES := SQLERRM;
    ROLLBACK;
    RETURN;
END UPZRBM;
/

