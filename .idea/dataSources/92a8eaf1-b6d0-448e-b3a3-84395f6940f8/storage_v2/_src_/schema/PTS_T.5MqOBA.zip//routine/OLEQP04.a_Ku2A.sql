create PROCEDURE OLEQP04(S_CFZDM IN VARCHAR2,
                                    S_ZJDZ  IN VARCHAR2,
                                    I_FHGS  IN INTEGER,
                                    CODES   OUT VARCHAR2) IS
  /*  采番公用方法
  * SCFZDM VARCHAR2  采番字段名
  * SZJDZ VARCHAR2 中间段值
  * IFHGS INTEGER 需要番号个数,从1开始
  * RETURN 返回计算所得番号,复数情况逗号连接
  */

  --定义变量
  S_TWZ    VARCHAR2(10); --头文字
  C_WWZ    CHARACTER; --尾文字
  --C_NWWZ    CHARACTER; --新的尾文字
  I_LSHCD  INTEGER := 0; --流水号长度
  I_DQLSH  INTEGER := 0; --当前流水号
  B_FLAG   BOOLEAN := TRUE; --是否第一次采番
  CURSOR_1 INTEGER := 1; --循环标量
  IS_FIRST INTEGER :=0;-- 标记是否是第一次采番
BEGIN
  --判断本次采番是否第一次采番: OLEQF01(S_CFZDM, S_ZJDZ)
  --根据采番表中对应的记录条数决定后续处理
  --0条：基准数据不存在，后续不做处理或返回异常
  --1条：仅存在基础数据，为首次采番，后续写入一条采番数据
  --2条：存在基准数据与采番数据，后续更新采番数据
    IS_FIRST := OLEQF01(S_CFZDM, S_ZJDZ);
  
  IF (IS_FIRST = 0) THEN
    CODES := 'ERROR';
    RETURN;
  ELSIF(IS_FIRST = 1) THEN
      B_FLAG := TRUE;
  ELSIF (IS_FIRST = 2) THEN
        B_FLAG := FALSE;
  END IF;

  --设置待采番数据的基础属性: 非初次采番时
  IF (B_FLAG = FALSE) THEN
     SELECT TWZ, LSHCD, DQLSH,WWZ
      INTO  S_TWZ, I_LSHCD, I_DQLSH,C_WWZ
     FROM XT_CF
     WHERE (CFZDM = S_CFZDM AND ZJDZ = S_ZJDZ);
   ELSIF (B_FLAG = TRUE) THEN
     SELECT TWZ, LSHCD, DQLSH,WWZ
      INTO  S_TWZ, I_LSHCD, I_DQLSH,C_WWZ
     FROM XT_CF
     WHERE (CFZDM = S_CFZDM AND ZJDZ = '*');
     --插入一条新记录
     INSERT INTO XT_CF
      (CFZDM, ZJDZ, TWZ, LSHCD, DQLSH,WWZ)
      VALUES
      (S_CFZDM, S_ZJDZ, S_TWZ, I_LSHCD, I_DQLSH,C_WWZ);
  END IF;
  --计算新的最大流水号,以及每个返回番号中的流水号；
  IF (I_FHGS <= 0) THEN
    CODES := 'ERROR';
    RETURN;
  ELSE
    LOOP
      EXIT WHEN CURSOR_1 = I_FHGS + 1;
      --当流水号达到最大长度时，自动置初始值
      IF (I_DQLSH = OLEQF03(I_LSHCD)) THEN
        I_DQLSH := 0;
        
        -- 如果是计划号 达到最大流水 变更尾字段
        IF (S_CFZDM = 'ET' OR S_CFZDM = 'PT')THEN
           C_WWZ :=OLEQF04(C_WWZ);
        END IF;
      END IF;
       I_DQLSH  := I_DQLSH + 1;
       CURSOR_1 := CURSOR_1 + 1;
       --正常采番的，按 头文字+中间段+固定长度拼接0的流水号；
            IF (CURSOR_1 < I_FHGS + 1) THEN
              IF(S_CFZDM = 'ET' OR S_CFZDM = 'PT' )THEN
                CODES := CODES || S_TWZ || S_ZJDZ ||C_WWZ||OLEQF02(TO_CHAR(I_DQLSH), I_LSHCD) || ',';
              ELSE 
                CODES := CODES || S_TWZ || S_ZJDZ ||OLEQF02(TO_CHAR(I_DQLSH), I_LSHCD) || ',';
              END IF;
            ELSE
                IF(S_CFZDM = 'ET' OR S_CFZDM = 'PT')THEN
                 CODES := CODES || S_TWZ || S_ZJDZ ||C_WWZ ||OLEQF02(TO_CHAR(I_DQLSH), I_LSHCD);
              ELSE 
                 CODES := CODES || S_TWZ || S_ZJDZ ||OLEQF02(TO_CHAR(I_DQLSH), I_LSHCD);
              END IF;
             
            END IF;
    END LOOP;
  END IF;

  --更新采番数据中的当前流水号;
  UPDATE XT_CF
     SET DQLSH = I_DQLSH,WWZ = C_WWZ
   WHERE CFZDM = S_CFZDM
     AND ZJDZ = S_ZJDZ;

EXCEPTION
  WHEN OTHERS THEN
    CODES := 'ERROR';
    ROLLBACK;
    RETURN;
END OLEQP04;
/

