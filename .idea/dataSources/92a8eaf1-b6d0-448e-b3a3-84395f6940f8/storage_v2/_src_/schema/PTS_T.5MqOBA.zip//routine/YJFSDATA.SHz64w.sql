create PROCEDURE YJFSDATA( CODES   OUT VARCHAR2) IS
V_XMBH                 VARCHAR2(10):='';--项目编号
V_JEH                     VARCHAR2(20):='';--JE号
V_ZZ                      VARCHAR2(10):='';--制造路线
V_ZP                      VARCHAR2(10):='';--装配路线
V_CPTZSNR               VARCHAR2(500):=''; --产品通知书内容
V_PTCPTZS               VARCHAR2(500):='';  --配套产品通知书
V_SQX                     VARCHAR2(500):='';  --双亲项
V_QXLJH                   VARCHAR2(20):=''; --零件变更信息_取消_零件号
V_QXLJMC                VARCHAR2(100):='';--零件变更信息_取消_零件名称
V_QXBB                  VARCHAR2(20):=''; --零件变更信息_取消_版本
V_QXZCXS                INTEGER; --零件变更信息_取消_装车系数
V_QXLJHDYS             VARCHAR2(100):=''; --零件变更信息_取消_零件号(带颜色)
V_CYLJH                   VARCHAR2(20):=''; --零件变更信息_采用_零件号
V_CYLJMC                VARCHAR2(100):=''; --零件变更信息_采用_零件名称
V_CYBB                   VARCHAR2(20):=''; --零件变更信息_采用_版本
V_CYZCXS                 INTEGER; --零件变更信息_采用_装车系数
V_CYLJHDYS               VARCHAR2(100):=''; --零件变更信息_采用_零件号(带颜色)
V_SYCX                   VARCHAR2(100):=''; --适用车型
V_MAINID             INTEGER; -- JE明细 表id
V_LSH                    INTEGER;
V_CGBGZYJYJTGSJ DATE;--采购部_工装样件预计提供时间
V_CGBGZYJSJTGSJ DATE;--采购部_工装样件实际提供时间
V_ZZBGYHYJZBSJ  DATE;
V_ZZBGYKYJWCSJ DATE;
V_ZLBSZCS            INTEGER;
V_ZLBSZJSFHG      VARCHAR2(100):='';
V_ZLBSZWT          DATE;
V_SCZBSSZJHSJ    DATE;
V_SCZBSSZJL        VARCHAR2(500);
V_ZZBGZYJYJTGSJ DATE;
V_ZZBGZYJSJTGSJ DATE;
   -- 游标
   -- 查询未完成JE填写的 所有JE
      CURSOR JEGKLJ_DATA IS
       SELECT B.ID,A.LSH,A.JEH,CPTZSNR, PTCPTZS,SQX,
         QXLJH, QXLJMC,QXBB,QXZCXS, QXLJHDYS,
         CYLJH, CYLJMC,CYBB,CYZCXS,CYLJHDYS,
         SYCX, XMBH, ZZ,ZP,
         CGBGZYJYJTGSJ,CGBGZYJSJTGSJ,
         ZZBGZYJYJTGSJ,ZZBGZYJSJTGSJ,ZZBGYHYJZBSJ,ZZBGYKYJWCSJ,
         ZLBSZCS, ZLBSZJSFHG,ZLBSZWT,SCZBSSZJHSJ,SCZBSSZJL
        FROM XM_JEGK A
       FULL JOIN XM_JEGKMX B
        ON A.JEH = B.JEH AND A.LSH = B.LSH 
       WHERE JESFTXWC =0  AND ZZ IS NOT NULL  AND ZP IS  NOT  NULL AND (A.ZFZT IS  NULL OR A.ZFZT ='0' );
      JEGKLJ_DATA_RECORD JEGKLJ_DATA%rowtype;
      
    

BEGIN
      
     -- 循环所有JE零件  查出符合发送邮件条件的记录
      OPEN JEGKLJ_DATA;
          LOOP
            FETCH JEGKLJ_DATA
               INTO JEGKLJ_DATA_RECORD;
               EXIT WHEN JEGKLJ_DATA%notfound;
                V_XMBH := JEGKLJ_DATA_RECORD.XMBH;
                V_JEH := JEGKLJ_DATA_RECORD.JEH;
                V_MAINID:=JEGKLJ_DATA_RECORD.ID;
                V_ZZ := JEGKLJ_DATA_RECORD.ZZ;
                V_ZP := JEGKLJ_DATA_RECORD.ZP;
                V_CPTZSNR:=JEGKLJ_DATA_RECORD.Cptzsnr;
                v_ptcptzs:=JEGKLJ_DATA_RECORD.Ptcptzs;
                v_sqx:=JEGKLJ_DATA_RECORD.Sqx;
                v_qxljh:=JEGKLJ_DATA_RECORD.Qxljh;
                v_qxljmc:=JEGKLJ_DATA_RECORD.Qxljmc;
                v_qxbb:=JEGKLJ_DATA_RECORD.Qxbb;
                V_QXZCXS:=JEGKLJ_DATA_RECORD.Qxzcxs;
                V_QXLJHDYS:=JEGKLJ_DATA_RECORD.Qxljhdys;
                V_CYLJH:=JEGKLJ_DATA_RECORD.Cyljh;
                v_cyljmc:=JEGKLJ_DATA_RECORD.Cyljmc;
                V_CYBB:=JEGKLJ_DATA_RECORD.Cybb;
                V_CYZCXS:=JEGKLJ_DATA_RECORD.Cyzcxs;
                V_CYLJHDYS:=JEGKLJ_DATA_RECORD.Cyljhdys;
                V_SYCX:=JEGKLJ_DATA_RECORD.Sycx;
                 
                 V_LSH:=JEGKLJ_DATA_RECORD.LSH;
                V_CGBGZYJYJTGSJ:=JEGKLJ_DATA_RECORD.CGBGZYJYJTGSJ;
                V_CGBGZYJSJTGSJ:=JEGKLJ_DATA_RECORD.CGBGZYJSJTGSJ;
                V_ZZBGYHYJZBSJ  :=JEGKLJ_DATA_RECORD.ZZBGYHYJZBSJ;
                V_ZZBGYKYJWCSJ :=JEGKLJ_DATA_RECORD.ZZBGYKYJWCSJ;
                V_ZLBSZCS            :=JEGKLJ_DATA_RECORD.ZLBSZCS;
                V_ZLBSZJSFHG      :=JEGKLJ_DATA_RECORD.ZLBSZJSFHG;
                V_ZLBSZWT          :=JEGKLJ_DATA_RECORD.ZLBSZWT;
                V_SCZBSSZJHSJ    :=JEGKLJ_DATA_RECORD.SCZBSSZJHSJ ;
                V_SCZBSSZJL        :=JEGKLJ_DATA_RECORD.SCZBSSZJL;
                V_ZZBGZYJYJTGSJ :=JEGKLJ_DATA_RECORD.ZZBGZYJYJTGSJ;
                V_ZZBGZYJSJTGSJ :=JEGKLJ_DATA_RECORD.ZZBGZYJSJTGSJ;
                
                
                -- 先判断该零件是外制件 还是内制件
                IF(V_ZZ LIKE '%CG%')THEN -- 外制件
                 --如果采购部_工装样件预计提供时间为空需要插入邮件发送表
                      IF(V_CGBGZYJYJTGSJ IS NULL) THEN
                             INSERT INTO XM_TDYJFS
                              (ID,LSH,JEH, CPTZSNR, PTCPTZS,  SQX, QXLJH, QXLJMC, 
                                 QXBB, QXZCXS, QXLJHDYS, CYLJH, CYLJMC, 
                                 CYBB, CYZCXS, CYLJHDYS, SYCX, ZZ, ZP, 
                                 XMBH,ZDMC, BMBH,MAINID, ZDLM)
                            VALUES
                              ( SEQ_MAIL.NEXTVAL,V_LSH,V_JEH, V_CPTZSNR, V_PTCPTZS,  V_SQX, V_QXLJH, V_QXLJMC,
                               V_QXBB, V_QXZCXS, V_QXLJHDYS, V_CYLJH, V_CYLJMC, 
                               V_CYBB, V_CYZCXS, V_CYLJHDYS, V_SYCX, V_ZZ, V_ZP, 
                               V_XMBH, '工装样件预计提供时间','0003',V_MAINID ,'CGBGZYJYJTGSJ');
                      END IF;
                       --如果采购部_工装样件预计提供时间不为空
                       --判断采购部_工装样件实际提供时间是否为空 为空则 需要插入邮件发送表
                      IF(V_CGBGZYJYJTGSJ IS NOT NULL AND V_CGBGZYJSJTGSJ IS NULL )THEN
                            INSERT INTO XM_TDYJFS
                              (ID,LSH,JEH, CPTZSNR, PTCPTZS,  SQX, QXLJH, QXLJMC, 
                                 QXBB, QXZCXS, QXLJHDYS, CYLJH, CYLJMC, 
                                 CYBB, CYZCXS, CYLJHDYS, SYCX, ZZ, ZP, 
                                 XMBH, ZDMC, BMBH,MAINID, ZDLM)
                            VALUES
                              (SEQ_MAIL.NEXTVAL ,V_LSH,V_JEH, V_CPTZSNR, V_PTCPTZS,  V_SQX, V_QXLJH, V_QXLJMC,
                               V_QXBB, V_QXZCXS, V_QXLJHDYS, V_CYLJH, V_CYLJMC, 
                               V_CYBB, V_CYZCXS, V_CYLJHDYS, V_SYCX, V_ZZ, V_ZP, 
                               V_XMBH, '工装样件实际提供时间', '0003',V_MAINID ,'CGBGZYJSJTGSJ');
                      END IF;
                       --如果采购部_工装样件预计提供时间不为空
                       --制造工程部_工业化预计准备时间 、制造工程部_工艺卡预计完成时间 为空 需要插入邮件发送表
                      IF(V_CGBGZYJYJTGSJ IS NOT NULL AND (V_ZZBGYHYJZBSJ IS NULL OR V_ZZBGYKYJWCSJ IS NULL) )THEN
                           INSERT INTO XM_TDYJFS
                              (ID,LSH,JEH, CPTZSNR, PTCPTZS,  SQX, QXLJH, QXLJMC, 
                                 QXBB, QXZCXS, QXLJHDYS, CYLJH, CYLJMC, 
                                 CYBB, CYZCXS, CYLJHDYS, SYCX, ZZ, ZP, 
                                 XMBH, ZDMC, BMBH,MAINID, ZDLM)
                            VALUES
                              (SEQ_MAIL.NEXTVAL, V_LSH,V_JEH, V_CPTZSNR, V_PTCPTZS,  V_SQX, V_QXLJH, V_QXLJMC,
                               V_QXBB, V_QXZCXS, V_QXLJHDYS, V_CYLJH, V_CYLJMC, 
                               V_CYBB, V_CYZCXS, V_CYLJHDYS, V_SYCX, V_ZZ, V_ZP, 
                               V_XMBH, '工业化预计准备时间，工艺卡预计完成时间 ', '0004',V_MAINID  ,'ZZBGYHYJZBSJ,ZZBGYKYJWCSJ');
                     END IF;
                     --采购部_工装样件实际提供时间 不为空
                     --质量保证部_试装次数、 质量保证部_试装件是否合格 、质量保证部_试装委托提交时间 为空   需要插入邮件发送表
                     IF(V_CGBGZYJSJTGSJ IS NOT NULL  AND ( V_ZLBSZCS IS NULL OR V_ZLBSZJSFHG IS NULL OR V_ZLBSZWT IS NULL))THEN
                          INSERT INTO XM_TDYJFS
                              (ID,LSH,JEH, CPTZSNR, PTCPTZS,  SQX, QXLJH, QXLJMC, 
                                 QXBB, QXZCXS, QXLJHDYS, CYLJH, CYLJMC, 
                                 CYBB, CYZCXS, CYLJHDYS, SYCX, ZZ, ZP, 
                                 XMBH, ZDMC, BMBH,MAINID , ZDLM)
                            VALUES
                              (SEQ_MAIL.NEXTVAL, V_LSH,V_JEH, V_CPTZSNR, V_PTCPTZS,  V_SQX, V_QXLJH, V_QXLJMC,
                               V_QXBB, V_QXZCXS, V_QXLJHDYS, V_CYLJH, V_CYLJMC, 
                               V_CYBB, V_CYZCXS, V_CYLJHDYS, V_SYCX, V_ZZ, V_ZP, 
                               V_XMBH, '试装次数，试装件是否合格,试装委托提交时间 ', '0005',V_MAINID ,'ZLBSZCS,ZLBSZJSFHG,ZLBSZWT' );
                     END IF;
                 ELSE--IF(V_ZZ = 'ZZ')THEN --内制件
                       --如果制造工程部_工装样件预计提供时间为空需要插入邮件发送表
                      IF(V_ZZBGZYJYJTGSJ IS NULL) THEN
                             INSERT INTO XM_TDYJFS
                              (ID,LSH,JEH, CPTZSNR, PTCPTZS,  SQX, QXLJH, QXLJMC, 
                                 QXBB, QXZCXS, QXLJHDYS, CYLJH, CYLJMC, 
                                 CYBB, CYZCXS, CYLJHDYS, SYCX, ZZ, ZP, 
                                 XMBH, ZDMC, BMBH,MAINID,ZDLM)
                            VALUES
                              (SEQ_MAIL.NEXTVAL, V_LSH,V_JEH, V_CPTZSNR, V_PTCPTZS,  V_SQX, V_QXLJH, V_QXLJMC,
                               V_QXBB, V_QXZCXS, V_QXLJHDYS, V_CYLJH, V_CYLJMC, 
                               V_CYBB, V_CYZCXS, V_CYLJHDYS, V_SYCX, V_ZZ, V_ZP, 
                               V_XMBH, '工装样件预计提供时间', '0004',V_MAINID,'ZZBGZYJYJTGSJ' );
                      END IF;
                       --如果制造工程部_工装样件预计提供时间不为空
                       --判断制造工程部_工装样件实际提供时间是否为空 为空则 需要插入邮件发送表
                      IF(V_ZZBGZYJYJTGSJ IS NOT NULL AND V_ZZBGZYJSJTGSJ IS NULL )THEN
                            INSERT INTO XM_TDYJFS
                              (ID,LSH,JEH, CPTZSNR, PTCPTZS,  SQX, QXLJH, QXLJMC, 
                                 QXBB, QXZCXS, QXLJHDYS, CYLJH, CYLJMC, 
                                 CYBB, CYZCXS, CYLJHDYS, SYCX, ZZ, ZP, 
                                 XMBH, ZDMC, BMBH,MAINID,ZDLM)
                            VALUES
                              ( SEQ_MAIL.NEXTVAL,V_LSH,V_JEH, V_CPTZSNR, V_PTCPTZS,  V_SQX, V_QXLJH, V_QXLJMC,
                               V_QXBB, V_QXZCXS, V_QXLJHDYS, V_CYLJH, V_CYLJMC, 
                               V_CYBB, V_CYZCXS, V_CYLJHDYS, V_SYCX, V_ZZ, V_ZP, 
                               V_XMBH, '工装样件实际提供时间', '0004',V_MAINID,'ZZBGZYJSJTGSJ' );
                      END IF;
                       --如果制造工程部_工装样件预计提供时间不为空
                       --制造工程部_工业化预计准备时间 、制造工程部_工艺卡预计完成时间 为空 需要插入邮件发送表
                      IF(V_ZZBGZYJYJTGSJ IS NOT NULL AND (V_ZZBGYHYJZBSJ IS NULL OR V_ZZBGYKYJWCSJ IS NULL) )THEN
                           INSERT INTO XM_TDYJFS
                              (ID,LSH,JEH, CPTZSNR, PTCPTZS,  SQX, QXLJH, QXLJMC, 
                                 QXBB, QXZCXS, QXLJHDYS, CYLJH, CYLJMC, 
                                 CYBB, CYZCXS, CYLJHDYS, SYCX, ZZ, ZP, 
                                 XMBH, ZDMC, BMBH,MAINID,ZDLM)
                            VALUES
                              ( SEQ_MAIL.NEXTVAL,V_LSH,V_JEH, V_CPTZSNR, V_PTCPTZS,  V_SQX, V_QXLJH, V_QXLJMC,
                               V_QXBB, V_QXZCXS, V_QXLJHDYS, V_CYLJH, V_CYLJMC, 
                               V_CYBB, V_CYZCXS, V_CYLJHDYS, V_SYCX, V_ZZ, V_ZP, 
                               V_XMBH, '工业化预计准备时间,工艺卡预计完成时间', '0004',V_MAINID,'ZZBGYHYJZBSJ,ZZBGYKYJWCSJ' );
                     END IF;
                     --采购部_工装样件实际提供时间 不为空
                     --质量保证部_试装次数、 质量保证部_试装件是否合格 、质量保证部_试装委托提交时间 为空   需要插入邮件发送表
                     IF(V_ZZBGZYJSJTGSJ IS NOT NULL  AND ( V_ZLBSZCS IS NULL OR V_ZLBSZJSFHG IS NULL OR V_ZLBSZWT IS NULL))THEN
                          INSERT INTO XM_TDYJFS
                              (ID,LSH,JEH, CPTZSNR, PTCPTZS,  SQX, QXLJH, QXLJMC, 
                                 QXBB, QXZCXS, QXLJHDYS, CYLJH, CYLJMC, 
                                 CYBB, CYZCXS, CYLJHDYS, SYCX, ZZ, ZP, 
                                 XMBH, ZDMC, BMBH,MAINID,ZDLM)
                            VALUES
                              ( SEQ_MAIL.NEXTVAL,V_LSH,V_JEH, V_CPTZSNR, V_PTCPTZS,  V_SQX, V_QXLJH, V_QXLJMC,
                               V_QXBB, V_QXZCXS, V_QXLJHDYS, V_CYLJH, V_CYLJMC, 
                               V_CYBB, V_CYZCXS, V_CYLJHDYS, V_SYCX, V_ZZ, V_ZP, 
                               V_XMBH, '试装次数,试装件是否合格,试装委托提交时间 ', '0005',V_MAINID,'ZLBSZCS,ZLBSZJSFHG,ZLBSZWT' );
                     END IF;
                END IF;
                
                  --质量保证部_试装委托提交时间 不为空
                     --生产准备室_试装计划时间 为空  需要插入邮件发送表
                     IF(V_ZLBSZWT IS NOT NULL AND V_SCZBSSZJHSJ IS NULL)THEN 
                         INSERT INTO XM_TDYJFS
                              (ID,LSH,JEH, CPTZSNR, PTCPTZS,  SQX, QXLJH, QXLJMC, 
                                 QXBB, QXZCXS, QXLJHDYS, CYLJH, CYLJMC, 
                                 CYBB, CYZCXS, CYLJHDYS, SYCX, ZZ, ZP, 
                                 XMBH, ZDMC, BMBH,MAINID,ZDLM)
                            VALUES
                              (SEQ_MAIL.NEXTVAL, V_LSH,V_JEH, V_CPTZSNR, V_PTCPTZS,  V_SQX, V_QXLJH, V_QXLJMC,
                               V_QXBB, V_QXZCXS, V_QXLJHDYS, V_CYLJH, V_CYLJMC, 
                               V_CYBB, V_CYZCXS, V_CYLJHDYS, V_SYCX, V_ZZ, V_ZP, 
                               V_XMBH, '试装计划时间', '0006',V_MAINID,'SCZBSSZJHSJ' );
                     END IF;
                     --生产准备室_试装计划时间 不为空
                     --生产准备室_试装结论 为空 需要插入邮件发送表
                     IF(V_SCZBSSZJHSJ IS NOT NULL AND V_SCZBSSZJL IS NULL)THEN 
                        INSERT INTO XM_TDYJFS
                              (ID,LSH,JEH, CPTZSNR, PTCPTZS,  SQX, QXLJH, QXLJMC, 
                                 QXBB, QXZCXS, QXLJHDYS, CYLJH, CYLJMC, 
                                 CYBB, CYZCXS, CYLJHDYS, SYCX, ZZ, ZP, 
                                 XMBH, ZDMC, BMBH,MAINID,ZDLM,SCZBSSZJHSJ)
                            VALUES
                              ( SEQ_MAIL.NEXTVAL,V_LSH,V_JEH, V_CPTZSNR, V_PTCPTZS,  V_SQX, V_QXLJH, V_QXLJMC,
                               V_QXBB, V_QXZCXS, V_QXLJHDYS, V_CYLJH, V_CYLJMC, 
                               V_CYBB, V_CYZCXS, V_CYLJHDYS, V_SYCX, V_ZZ, V_ZP, 
                               V_XMBH, '试装结论', '0006',V_MAINID ,'SCZBSSZJL',V_SCZBSSZJHSJ);
                     END IF;
             -- 循环所有JE零件 结束
          END LOOP;
    CLOSE JEGKLJ_DATA;   
           

        -- 将邮件发送表中的记录与当天查询的记录做一比较
        -- 删除邮件表中不需要发送邮件的零件信息
           DELETE FROM XM_YJFS a 
           WHERE　NOT EXISTS 
           (SELECT *
          FROM XM_TDYJFS b
          WHERE A.XMBH = B.XMBH
          AND A.JEH = B.JEH
           AND A.LSH = B.LSH
          and a.MAINID = b.mainid
          and a.BMBH = b.bmbh
          and a.ZDLM = b.zdlm);
          
          
        -- 将邮件发送表中的记录与当天查询的记录做一比较
        -- 删除当天查询的记录已存在邮件表中的记录
          DELETE FROM XM_TDYJFS a 
           WHERE EXISTS 
           (SELECT *
          FROM XM_YJFS b
          WHERE A.XMBH = B.XMBH
          AND A.JEH = B.JEH
          AND A.LSH = B.LSH
          and a.MAINID = b.mainid
          and a.BMBH = b.bmbh
          and a.ZDLM = b.zdlm);
    

    
       -- 插入邮件发送表
        INSERT INTO XM_YJFS
          (ID,LSH,JEH, CPTZSNR, PTCPTZS, MAINID, SQX, QXLJH, QXLJMC, QXBB, QXZCXS, QXLJHDYS, CYLJH, CYLJMC, CYBB, CYZCXS, CYLJHDYS, SYCX, ZZ, ZP, XMBH, ZDMC, BMBH, FSSJ, ZDLM, SCZBSSZJHSJ)
         SELECT ID, LSH,JEH, CPTZSNR, PTCPTZS, MAINID, SQX, QXLJH, QXLJMC, QXBB, QXZCXS, QXLJHDYS, CYLJH, CYLJMC, CYBB, CYZCXS, CYLJHDYS, SYCX, ZZ, ZP, XMBH, ZDMC, BMBH, FSSJ, ZDLM, SCZBSSZJHSJ
         FROM XM_TDYJFS;
       
       -- 删除当天查询的记录  
        DELETE  FROM   XM_TDYJFS;

CODES :=   'SUCCESS';
EXCEPTION
  WHEN OTHERS THEN
    CODES:=sqlerrm;
    --CODES := 'ERROR';
    ROLLBACK;
    RETURN;
END YJFSDATA;
/

