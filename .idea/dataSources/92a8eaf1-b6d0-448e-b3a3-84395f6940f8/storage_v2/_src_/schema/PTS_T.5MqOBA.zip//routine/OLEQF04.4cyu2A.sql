create FUNCTION OLEQF04(WWZ IN CHARACTER) RETURN CHARACTER IS
/*根据传入的所需的流水号长度
返回该长度下的最大流水号*/
  NWWZ     CHARACTER;

BEGIN
   case when WWZ='A' then NWWZ :='B' ;
           when WWZ='B' then NWWZ := 'C'; 
           when WWZ='C' then NWWZ := 'D';
           when WWZ='D' then NWWZ := 'E';
            when WWZ='E' then NWWZ := 'F';
            when WWZ='F' then NWWZ := 'G';
             when WWZ='G' then NWWZ := 'H';
              when WWZ='H' then NWWZ := 'I';
               when WWZ='I' then NWWZ := 'J';
                when WWZ='J' then NWWZ := 'K';
                 when WWZ='K' then NWWZ := 'L';
                  when WWZ='L' then NWWZ := 'M';
                   when WWZ='M' then NWWZ := 'N';
                    when WWZ='N' then NWWZ := 'O';
                     when WWZ='O' then NWWZ := 'P';
                      when WWZ='P' then NWWZ := 'Q';
 when WWZ='Q' then NWWZ := 'R';
  when WWZ='R' then NWWZ := 'S';
   when WWZ='S' then NWWZ := 'T';
    when WWZ='T' then NWWZ := 'U';
     when WWZ='U' then NWWZ := 'V';
      when WWZ='V' then NWWZ := 'W';
       when WWZ='W' then NWWZ := 'X';
        when WWZ='X' then NWWZ := 'Y';
         when WWZ='Y' then NWWZ := 'Z';
          when WWZ='Z' then NWWZ := 'A';
             else NWWZ := 'A' ;
   end case;
  RETURN(NWWZ);
END OLEQF04;
/

