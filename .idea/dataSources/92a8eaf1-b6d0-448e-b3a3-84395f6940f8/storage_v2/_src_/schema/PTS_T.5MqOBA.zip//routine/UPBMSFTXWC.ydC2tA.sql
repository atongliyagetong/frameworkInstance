create PROCEDURE UPBMSFTXWC(I_LSH INTEGER,I_JEH IN VARCHAR2, -- 当前JE
                                    I_BMBH  IN VARCHAR2,  -- 当前部门
                                    CODES   OUT VARCHAR2) IS



V_NUM           INTEGER := 0;--部门该JEH填写的零件个数
V_BMZD        VARCHAR2(500):='';
S_SQL            VARCHAR2(1000):='';
S_DSQL          VARCHAR2(1000):='';
V_NUM1          INTEGER := 0;
-- 设游标  

 -- 查找部门对应字段
  CURSOR BMZD_DATA(I_BMBH IN VARCHAR2) IS
    SELECT  BMZD
      FROM XM_JEGK_BMZDB
     WHERE  BMBH = I_BMBH;
  BMZD_DATA_RECORD BMZD_DATA%rowtype;
BEGIN
  
     -- 查询本部门的所有字段 查看是否填写完毕
     OPEN BMZD_DATA(I_BMBH);
      LOOP
        FETCH BMZD_DATA
          INTO BMZD_DATA_RECORD;
        EXIT WHEN BMZD_DATA%notfound;
        V_BMZD   := BMZD_DATA_RECORD.BMZD;
        IF(S_SQL IS NULL OR S_SQL = '')THEN
                S_SQL :=  S_SQL||V_BMZD ||' IS NULL ';
        ELSE
                IF(I_BMBH ='0009' and V_BMZD='CPRKYJWCSJ')THEN
                   S_SQL :=  S_SQL||' OR (' ||V_BMZD || ' IS NULL  AND SFJXCPRK='||'''是'''||' )';
                ELSE 
                     S_SQL :=  S_SQL||' OR ' ||V_BMZD || ' IS NULL ';
                END IF;
        END IF;
      END LOOP;
    CLOSE BMZD_DATA;
     
      S_DSQL:='SELECT  COUNT(1)  FROM XM_JEGKMX WHERE   LSH = '||I_LSH ||' AND JEH = '''||I_JEH||'''  AND (' ||S_SQL ||')  AND ZZ IS NOT NULL AND CYLJH IS NOT NULL ';
      EXECUTE IMMEDIATE(S_DSQL) INTO  V_NUM;
      -- 如果为0则该部门填写完毕，更新本部门是否填写完毕字段为已填写完毕
     
       --SELECT COUNT(1)  INTO V_NUM1 FROM XM_JEGK WHERE    LSH = '||I_LSH ||' AND JEH = '''||I_JEH||'''  AND sfjsbom = 1;
        S_DSQL:='SELECT COUNT(1) FROM XM_JEGK WHERE LSH = '||I_LSH ||' AND JEH = '''||I_JEH||''' AND sfjsbom = 1 ';
        EXECUTE IMMEDIATE(S_DSQL) INTO V_NUM1;
       -- 导入完成才判断明细
       IF(V_NUM1 >0 )THEN 
        IF(I_BMBH='0001')THEN
            IF(V_NUM=0)THEN 
               UPDATE   XM_JEGK SET JSZXSFTX = 1 WHERE LSH=I_LSH AND  JEH=I_JEH;--技术中心
            ELSE 
              UPDATE   XM_JEGK SET JSZXSFTX = 0 WHERE LSH=I_LSH AND  JEH=I_JEH;--技术中心
            END IF;
        ELSIF(I_BMBH='0009')THEN
            IF(V_NUM=0)THEN 
                UPDATE   XM_JEGK SET SFKFBSFTX = 1 WHERE LSH=I_LSH AND  JEH=I_JEH;--商品开发部
            ELSE 
                UPDATE   XM_JEGK SET SFKFBSFTX = 0 WHERE  LSH=I_LSH AND JEH=I_JEH;--商品开发部
            END IF;    
        ELSIF(I_BMBH='0003')THEN
          IF(V_NUM=0)THEN 
              UPDATE   XM_JEGK SET CGBSFTX = 1 WHERE LSH=I_LSH AND  JEH=I_JEH;--采购部
          ELSE
              UPDATE   XM_JEGK SET CGBSFTX = 0 WHERE LSH=I_LSH AND  JEH=I_JEH;--采购部
          END IF;
        ELSIF(I_BMBH='0004')THEN
           IF(V_NUM=0)THEN 
            UPDATE   XM_JEGK SET ZZGCBSFTX = 1 WHERE  LSH=I_LSH AND  JEH=I_JEH;--制造工程部
           ELSE
             UPDATE   XM_JEGK SET ZZGCBSFTX = 0 WHERE LSH=I_LSH AND  JEH=I_JEH;--制造工程部
           END IF;
       ELSIF(I_BMBH='0005')THEN
          IF(V_NUM=0)THEN 
             UPDATE   XM_JEGK SET ZLBZBSFTX = 1 WHERE LSH=I_LSH AND  JEH=I_JEH;--质量保证部
           ELSE
              UPDATE   XM_JEGK SET ZLBZBSFTX = 0 WHERE LSH=I_LSH AND  JEH=I_JEH;--质量保证部
           END IF;
       ELSIF(I_BMBH='0006')THEN
          IF(V_NUM=0)THEN 
             UPDATE   XM_JEGK SET SCZBSSFTX = 1 WHERE LSH=I_LSH AND  JEH=I_JEH;--生产准备室
          ELSE
            UPDATE   XM_JEGK SET SCZBSSFTX = 0 WHERE  LSH=I_LSH AND  JEH=I_JEH;--生产准备室
          END IF;
        ELSIF(I_BMBH='0021')THEN
         IF(V_NUM=0)THEN 
          UPDATE   XM_JEGK SET SCJHSSFTX = 1 WHERE LSH=I_LSH AND  JEH=I_JEH;--生产计划室
          ELSE
            UPDATE   XM_JEGK SET SCJHSSFTX = 0 WHERE LSH=I_LSH AND  JEH=I_JEH;--生产计划室
        END IF;
      END IF;
      END IF;
      
      CODES :=   'SUCCESS';  
EXCEPTION
  WHEN OTHERS THEN
    CODES := 'ERROR';
    ROLLBACK;
    RETURN;
END UPBMSFTXWC;
/

