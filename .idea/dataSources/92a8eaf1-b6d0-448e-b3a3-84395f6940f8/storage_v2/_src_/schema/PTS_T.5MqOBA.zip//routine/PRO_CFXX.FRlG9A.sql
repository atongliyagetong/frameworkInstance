create procedure pro_cfxx(i_cfzdm in varchar2,o_codes out varchar2)  is
--------------------------------------------------------------------------------------------
                                            --采番公用方法--
--规则：从0-Z增长，到Z进一位。

--参数说明：
--i_cfzdm  采番字段名
--o_codes 生成的新号码

--SYS_CFXX表说明：
--CFZDM（采番字段名）：订单类型（例如‘DDBH’：采番订单单号）
--TWZ（头文字）：生成的编号的前缀
--WWZ（尾文字）：生成的编号的尾部分
--LSHCD（流水部分长度）
--KSLSH（开始流水号）：流水号从此值开始
--JSLSH（结束流水号）：流水号到此值结束
--DQLSH（当前流水号）：当前已用到的流水号
--ISBL（是否补零 0：否、1：是）：是补零，则在流水号前补零，补满流水部分长度。
--ISXH（是否循环 0：否、1：是）：是，到了结束流水号，从开始流水号再开始踩番；否，返回一个空。


--将“I”与“O”屏蔽 20140526

--------------------------------------------------------------------------------------------

       v_cfxx sys_cfxx % rowtype ;
       v_sclsh varchar2 (200); --上次流水号



       v_newlsh varchar2(200):='';--新流水号
       v_len integer;--上次流水号长度
       v_temp integer:=1;--增量
       v_val char;--流水号每一位

       sqlStr varchar2(400):='';
       upd_cnt integer;

begin

    select * into v_cfxx from sys_cfxx  where cfzdm =i_cfzdm ;
    v_sclsh := nvl(v_cfxx.dqlsh,v_cfxx.kslsh);--当前流水号为空就去开始流水号

    --如果设置了结束流水号，判断是否到了结束的流水
    if v_sclsh >= v_cfxx.jslsh then
              if v_cfxx.isxh = 1 then --是否循环
                        v_newlsh := v_cfxx.kslsh;--循环就使用开始流水号
              else
                        o_codes:=null;
                        return;
              end if;
    else
              v_len:=length(v_sclsh);
              --流水号+1
              for x in 0..v_len-1  loop
                       v_val:= substr(v_sclsh,v_len-x,1);
                       if v_temp=1 then
                              if ascii(v_val) < ascii('9') then
                                   v_val:=chr(ascii(v_val)+v_temp);
                                   v_temp:= 0;
                              elsif  ascii(v_val) = ascii('9') then
                                   v_val:= 'A';
                                   v_temp:= 0;
                              elsif  ascii(v_val) < ascii('Z') then
                                   v_val:=chr(ascii(v_val)+v_temp);
                                   --将“I”与“O”屏蔽 20140526
                                   if v_val = 'O' or v_val = 'I'  then
                                         v_val:=chr(ascii(v_val)+1);
                                   end if;
                                   v_temp:= 0;
                               else
                                  v_val:= 0;
                                  v_temp:= 1;
                               end if ;
                       end if;

                       --dbms_output.put_line(v_val);
                       v_newlsh := v_val||v_newlsh;
              end loop;
              --dbms_output.put_line('v_newlsh:'||v_newlsh);


              if v_temp = 1 then --流水号进了一位
                   if v_len < v_cfxx.lshcd then --是否长度满了
                           v_newlsh := v_temp||v_newlsh;
                   else
                           if v_cfxx.isxh = 1 then --是否循环
                                     v_newlsh := v_cfxx.kslsh;
                            else
                                     o_codes:=null;
                                     return;
                           end if;
                   end if;
              end if;


              --判断是否超过了结束的流水
              if v_newlsh > v_cfxx.jslsh then
                        if v_cfxx.isxh = 1 then --是否循环
                                  v_newlsh := v_cfxx.kslsh;--循环就使用开始流水号
                        else
                                  o_codes:=null;
                                  return;
                        end if;
              end if;

    end if;




    --更新数据库
    sqlStr := 'update sys_cfxx set  dqlsh = '''||v_newlsh||'''  where cfzdm = '''||i_cfzdm||'''';

    --防止并发
    if v_cfxx.dqlsh is null or v_cfxx.dqlsh='' then
               sqlStr := sqlStr||' and dqlsh is null';
    else
               sqlStr := sqlStr||' and dqlsh = '''||v_cfxx.dqlsh||'''';
     end if;

    --dbms_output.put_line('sqlStr:'||sqlStr);
    execute immediate sqlStr;
    upd_cnt:=SQL%ROWCOUNT;
    --commit;


    --dbms_output.put_line('upd_cnt:'||upd_cnt);
    if upd_cnt=0 then
                pro_cfxx(i_cfzdm,o_codes);--产生并发，重算
    else
                --补零
                if v_cfxx.isbl = 1 then
                      if length(v_newlsh) < v_cfxx.lshcd then
                            for  y in length(v_newlsh)..v_cfxx.lshcd-1 loop
                                 v_newlsh:=0||v_newlsh;
                            end loop;
                      end if;
                end if;

                --完整的新号
                o_codes:=v_cfxx.twz || v_newlsh||v_cfxx.wwz;
    end if;

    --dbms_output.put_line('o_codes:'||o_codes);


end pro_cfxx;
/

