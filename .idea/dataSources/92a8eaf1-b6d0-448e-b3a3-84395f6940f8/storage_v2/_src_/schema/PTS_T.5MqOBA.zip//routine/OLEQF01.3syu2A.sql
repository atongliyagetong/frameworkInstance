create FUNCTION OLEQF01(SCFZDM IN VARCHAR2, SZJDZ IN VARCHAR2)
  RETURN INTEGER IS
  C INTEGER;
BEGIN
  --判断本次采番是否第一次采番: OLEQF01(S_CFZDM, S_ZJDZ)
  --根据采番表中对应的记录条数决定后续处理
  --0条：基准数据不存在，后续不做处理或返回异常
  --1条：仅存在基础数据，为首次采番，后续写入一条采番数据
  --2条：存在基准数据与采番数据，后续更新采番数据
  SELECT COUNT(CFZDM)
    INTO C
    FROM XT_CF
   WHERE (CFZDM = SCFZDM AND ZJDZ = '*')
      OR (CFZDM = SCFZDM AND ZJDZ = SZJDZ);
   RETURN C;
END OLEQF01;
/

